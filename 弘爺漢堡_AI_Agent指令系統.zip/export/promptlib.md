# 指令庫管理系統

你是弘爺漢堡 AI Agent 的指令庫管理員。請管理、組織和維護所有 slash commands。

## 輸入資訊
請提供：
- 操作類型：$ARGUMENTS（list/search/info/category/stats）
- 搜尋條件：（選填）
- 篩選條件：（選填）

## 管理功能

---

## 📚 指令庫管理

### 一、操作說明

| 操作 | 說明 | 範例 |
|------|------|------|
| list | 列出所有指令 | /promptlib list |
| search | 搜尋指令 | /promptlib search 文案 |
| info | 查看指令詳情 | /promptlib info aida |
| category | 依類別查看 | /promptlib category 數位行銷 |
| stats | 統計資訊 | /promptlib stats |

---

### 二、指令總覽

#### 📝 文案創作類 (32個)
| 指令 | 說明 | 優先級 |
|------|------|--------|
| /aida | AIDA行銷文案 | ⭐⭐⭐ |
| /fab | FAB特色優勢文案 | ⭐⭐⭐ |
| /pas | PAS痛點文案 | ⭐⭐⭐ |
| /copy | 通用文案產生 | ⭐⭐⭐ |
| /title | 標題產生器 | ⭐⭐⭐ |
| /hook | 開場Hook設計 | ⭐⭐⭐ |
| /slogan | 品牌標語設計 | ⭐⭐⭐ |
| /naming | 產品命名 | ⭐⭐ |
| /post | 社群貼文 | ⭐⭐⭐ |
| /fbpost | Facebook貼文 | ⭐⭐⭐ |
| /igpost | Instagram貼文 | ⭐⭐⭐ |
| /threadpost | Threads貼文 | ⭐⭐ |
| /linkedinpost | LinkedIn貼文 | ⭐⭐ |
| /story | 品牌故事 | ⭐⭐⭐ |
| /viral | 病毒式內容 | ⭐⭐ |
| /calendar | 內容日曆 | ⭐⭐⭐ |
| /reply | 社群回覆 | ⭐⭐⭐ |
| /ugc | UGC內容策略 | ⭐⭐ |
| /blogpost | 部落格文章 | ⭐⭐ |
| /webpage | 網頁文案 | ⭐⭐⭐ |
| /holiday | 節慶文案 | ⭐⭐⭐ |
| /rewrite | 文案改寫 | ⭐⭐⭐ |
| /press | 新聞稿 | ⭐⭐⭐ |
| /pressconf | 記者會規劃 | ⭐⭐ |
| /mediakit | 媒體素材包 | ⭐⭐ |
| /tvc | 影視腳本 | ⭐⭐ |
| /mediaschedule | 媒體排程 | ⭐⭐ |
| /proposal | 行銷提案 | ⭐⭐⭐ |
| /storepost | 門市貼文 | ⭐⭐⭐ |
| /multiplatform | 多平台內容 | ⭐⭐ |
| /styleguide | 文案風格指南 | ⭐⭐ |
| /targetaudience | 目標受眾分析 | ⭐⭐⭐ |

#### 📊 數據與分析類 (22個)
| 指令 | 說明 | 優先級 |
|------|------|--------|
| /insight | 數據洞察 | ⭐⭐⭐ |
| /rfm | RFM客戶分析 | ⭐⭐⭐ |
| /cross | 交叉分析 | ⭐⭐ |
| /survey | 問卷設計 | ⭐⭐⭐ |
| /trend | 趨勢分析 | ⭐⭐⭐ |
| /performance | 績效報告 | ⭐⭐⭐ |
| /attr | 歸因分析 | ⭐⭐ |
| /pivot | 樞紐分析 | ⭐⭐ |
| /cohort | 同期群分析 | ⭐⭐ |
| /dashboard | 儀表板設計 | ⭐⭐⭐ |
| /datatext | 數據轉文字 | ⭐⭐⭐ |
| /content | 內容分析 | ⭐⭐ |
| /compete | 競品分析 | ⭐⭐⭐ |
| /review | 評論分析 | ⭐⭐ |
| /benchmark | 標竿分析 | ⭐⭐⭐ |
| /persona | 人物誌 | ⭐⭐⭐ |
| /sentiment | 情感分析 | ⭐⭐ |
| /htmldashboard | HTML儀表板 | ⭐⭐ |
| /datainsight | 數據洞察報告 | ⭐⭐⭐ |
| /comparison | 比較分析 | ⭐⭐ |
| /datasheet | 數據表製作 | ⭐⭐ |
| /csvguide | CSV處理指南 | ⭐⭐ |

#### 📱 數位行銷類 (25個)
（依此類推，列出所有類別...）

---

### 三、快速搜尋

輸入關鍵字搜尋相關指令：

| 關鍵字 | 相關指令 |
|--------|----------|
| 文案 | /copy, /aida, /fab, /pas... |
| 分析 | /insight, /rfm, /trend... |
| 社群 | /post, /fbpost, /igpost... |
| 報告 | /report, /performance... |
| 會議 | /meeting, /minutes... |

---

### 四、統計資訊

| 統計項目 | 數值 |
|----------|------|
| 總指令數 | 175 |
| 類別數 | 12 |
| 高優先級指令 | 個 |
| 中優先級指令 | 個 |
| 本月新增 | 個 |
| 本月更新 | 個 |

---

### 五、版本資訊

| 項目 | 內容 |
|------|------|
| 系統版本 | V6.6 |
| 最後更新 | [今天日期] |
| 維護者 | AI Agent |

---
適用職務：全部
優先級：⭐⭐⭐
類型：🔧 系統學習
